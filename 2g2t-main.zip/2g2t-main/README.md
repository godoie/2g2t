# Estudo Segundo Trimestre
Thales - 31
